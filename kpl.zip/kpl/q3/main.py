# all imports below

"""
Any extra lines of code (if required)
as helper for this function.
"""

def findDelay(dist):
	'''
	Parameters
	----------
	dist : A `float`
	
	Returns
	-------
	A `float`
	'''
	return NotImplementedError
