# all imports below

"""
Any extra lines of code (if required)
as helper for this function.
"""

def findDistance(vrec):
	'''
	Parameters
	----------
	vrec : a `float`
	
	Returns
	-------
	a `float`
	'''
	return NotImplementedError
