# all imports below

"""
Any extra lines of code (if required)
as helper for this function.
"""

def findstrike(velocity, alt, az):
	'''
	Parameters
	----------
	velocity : A `float`
    alt: A `float`
    az: A `float`
	
	Returns
	-------
	A `tuple` of two floats
	'''
	return NotImplementedError
